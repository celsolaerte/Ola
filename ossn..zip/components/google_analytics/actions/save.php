<?php
/**
 * Open Source Social Network
 *
 * @package   (softlab24.com).ossn
 * @author    OSSN Core Team <info@softlab24.com>
 * @copyright (C) SOFTLAB24 LIMITED
 * @license   Open Source Social Network License (OSSN LICENSE)  http://www.opensource-socialnetwork.org/licence
 * @link      https://www.opensource-socialnetwork.org/
 */

$component = new OssnComponents;

$ga_code = input('ga_code');

$settings = array(
	'ga_code' => $ga_code
);

if($component->setSettings('google_analytics', $settings)){
	ossn_trigger_message(ossn_print('ossn:admin:settings:saved'));
    redirect(REF);
} else {
	ossn_trigger_message(ossn_print('ossn:admin:settings:save:error'), 'error');
    redirect(REF);
}
